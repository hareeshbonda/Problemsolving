from page_objects.login_page import Login
from page_objects.credentials import secrets


class Test_001_Login:
    base_url = "https://practice.automationtesting.in/"
    username = secrets.get('USERNAME', 'root')
    password = secrets.get('PASSWORD', 'pass')

    def test_login(self, setup):
        self.driver = setup
        self.driver.get(self.base_url)
        self.lp = Login(self.driver)
        self.lp.account_button()
        self.lp.set_username(self.username)
        self.lp.set_password(self.password)
        self.lp.click_login()
        self.lp.check_dashboard()