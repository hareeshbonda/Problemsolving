secrets = {
    'USERNAME': "bondaharish@gmail.com",
    'PASSWORD': "Harishbonda@777",

}
