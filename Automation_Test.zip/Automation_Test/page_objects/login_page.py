from selenium.webdriver.common.by import By


class Login:
    text_box_username = "username"
    text_box_password = "password"
    button_login_link_text = "login"
    my_account_button = "My Account"
    dashboard_button = "Dashboard"

    def __init__(self, driver):
        self.driver = driver

    def set_username(self, username):
        self.driver.find_element(By.ID, self.text_box_username).clear()
        self.driver.find_element(By.ID, self.text_box_username).send_keys(username)

    def set_password(self, password):
        self.driver.find_element(By.ID, self.text_box_password).clear()
        self.driver.find_element(By.ID, self.text_box_password).send_keys(password)

    def account_button(self):
        self.driver.find_element(By.LINK_TEXT, self.my_account_button).click()

    def click_login(self):
        self.driver.find_element(By.NAME, self.button_login_link_text).click()

    def check_dashboard(self):
        dashboard = self.driver.find_element(By.LINK_TEXT, self.dashboard_button).get_attribute('text')
        assert dashboard == "Dashboard"
